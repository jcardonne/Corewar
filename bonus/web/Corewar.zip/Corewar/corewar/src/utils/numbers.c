/*
** EPITECH PROJECT, 2022
** corewar
** File description:
** numbers
*/

int absolute(long n)
{
    if (n < 0)
        return (n * -1);
    return (n);
}
