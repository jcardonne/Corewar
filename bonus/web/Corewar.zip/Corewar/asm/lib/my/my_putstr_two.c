/*
** EPITECH PROJECT, 2021
** my_putstr
** File description:
** Print string
*/

int my_putstr(char const *str);

void my_putstr_two(char const *one, char const *second)
{
    my_putstr(one);
    my_putstr(second);
}
